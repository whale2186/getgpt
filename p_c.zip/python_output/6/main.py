def collect_numbers():
    numbers = []  # Initialize an empty list to store numbers
    
    try:
        max_entries = int(input("Enter the total number: "))  # Get the total count from the user
    except ValueError:
        print("Please enter a valid integer for the total count.")
        return []  # Return an empty list if the input is invalid
    
    while len(numbers) < max_entries:
        user_input = input("Enter number one by one: ")
        
        if user_input.strip() == "":  # Check if the input is empty
            continue  # If empty, continue to the next iteration
        
        try:
            number = int(user_input)  # Convert input to an integer
            numbers.append(number)  # Add the number to the list
        except ValueError:
            print("Please enter a valid integer.")  # Handle invalid input

    return numbers  # Return the collected numbers

def find_min_max(numbers):
    if not numbers:  # Check if the list is empty
        return None, None  # Return None if the list is empty
    minimum = min(numbers)  # Find the minimum value
    maximum = max(numbers)  # Find the maximum value
    return minimum, maximum  # Return both values

# Collect numbers from the user
numbers_collected = collect_numbers()

# Find the minimum and maximum values
min_value, max_value = find_min_max(numbers_collected)

# Display the results
if min_value is not None and max_value is not None:
    print("Collected numbers:", numbers_collected)
    print("Minimum:", min_value)
    print("Maximum:", max_value)
else:
    print("No numbers were entered.")
