def reverse_list(input_list):
    # Reverse the list
    reversed_list = input_list[::-1]
    return reversed_list

# Example usage
if __name__ == "__main__":
    my_list = []

    while len(my_list) < 6:
        try:
            number = int(input(f"Enter number one by one: "))
            my_list.append(number)
        except ValueError:
            print("Invalid input. Please enter a number.")

    # Display the original and reversed lists
    print("Original List:", my_list)
    print("Reversed List:", reverse_list(my_list))
