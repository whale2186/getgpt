def longest_word_length(words):
    # Check if the list is empty
    if not words:
        return 0

    # Find the longest word length
    max_length = max(len(word) for word in words)
    return max_length

# Example usage
if __name__ == "__main__":
    # Ask the user how many words they want to enter
    try:
        num_words = int(input("Enter Number of words:  "))
    except ValueError:
        print("Invalid input. Please enter a valid number.")
        exit()

    # Initialize the list to store words
    word_list = []

    # Collect the words from the user
    for i in range(num_words):
        word = input("Enter words one by one :")
        word_list.append(word)

    # Get the length of the longest word
    length_of_longest = longest_word_length(word_list)

    print("Length of the longest word:", length_of_longest)
