text=input("Enter a line of text:")
vw=0
ch=0
sp=0
text=text.lower()
vowel='aeiou'
for i in text:
    if i in vowel:
        vw=vw+1
    if (i>='a' and i<='z'):
        ch=ch+1;
    else:
        sp=sp+1
print("Number of characters is : ",ch)
print("Number of vowels is : ",vw)
print("Number of blank spaces is: ", sp)
