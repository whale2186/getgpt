def modify_string(s):
    if len(s) < 3:
        return s  # Leave unchanged if less than 3 characters
    elif s.endswith('ing'):
        return s + 'ly'  # Add 'ly' if it already ends with 'ing'
    else:
        return s + 'ing'  # Add 'ing' if it has 3 or more characters

# Test the function
input_string = input("Enter a string: ")
result = modify_string(input_string)
print("Modified string:", result)
