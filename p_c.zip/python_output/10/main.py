def linear_search(elements, target):
    """Perform linear search to find the target in the elements."""
    for index, element in enumerate(elements):
        if element == target:
            return index  # Return the index of the found element
    return -1  # Return -1 if the element is not found

# Example usage
if __name__ == "__main__":
    # Ask the user for the number of elements
    try:
        num_elements = int(input("Enter the number of data:  "))
    except ValueError:
        print("Invalid input. Please enter a valid number.")
        exit()

    # Initialize the set to store numbers
    elements = []

    # Collect the numbers from the user
    for i in range(num_elements):
        while True:
            try:
                number = float(input("Enter next data: "))  # Allow float input
                elements.append(number)
                break
            except ValueError:
                print("Invalid input. Please enter a valid number.")

    # Ask the user for the element to search for
    while True:
        try:
            target = float(input("Enter the number to search for: "))
            break
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    # Perform linear search
    index = linear_search(elements, target)

    # Display the result
    if index != -1:
        print(f"Element {target} found at index {index}.")
    else:
        print(f"Element {target} not found in the list.")
