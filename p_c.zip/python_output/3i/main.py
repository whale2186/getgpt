text="Welcome to Python Programming"
text1="Welcome to Python Programming"
print("------Slicing operations------")
print(text[11:])
print(text[:17])
print(text[11:17])
print(text[0:17:2])
print()
print("--------Trim Operations-------")
print(text1)
print(text1.strip())
print(text1.lstrip())
print(text1.rstrip())
