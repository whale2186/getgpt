def fibonacci(n):
    # Initialize the first two Fibonacci numbers
    fib_1, fib_2 = 0, 1
    
    for i in range(n):
        if i == 0:
            print(fib_1)  # Print the first Fibonacci number
        elif i == 1:
            print(fib_2)  # Print the second Fibonacci number
        else:
            next_fib = fib_1 + fib_2  # Calculate the next Fibonacci number
            print(next_fib)  # Print the next Fibonacci number
            # Update fib_1 and fib_2 for the next iteration
            fib_1, fib_2 = fib_2, next_fib

# Get the number of terms from the user
n = int(input("Enter the number of terms in Fibonacci series: "))
print("Fibonacci series:")
fibonacci(n)
