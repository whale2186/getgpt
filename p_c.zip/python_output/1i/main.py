a=(int(input('Enter First Number: ')))
b=(int(input('Enter Second Number: ')))
a1=a
b1=b
while b!=0:
    t=b
    b=a%b
    a=t
print("The GCD of ({},{}) is {}".format(a1,b1,a))
