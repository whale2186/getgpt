def print_tuple_halves(input_tuple):
    # Calculate the midpoint
    mid_index = len(input_tuple) // 2

    # Print the first half
    print("First Half:", end=" ")
    print(*input_tuple[:mid_index])

    # Print the second half
    print("Second Half:", end=" ")
    print(*input_tuple[mid_index:])

# Example usage
if __name__ == "__main__":
    # Example tuple with strings and floats
    my_tuple = ("Apple", 3.14, "Banana", 2.71, "Cherry", 1.62, "Dates", 0.57)

    print_tuple_halves(my_tuple)
