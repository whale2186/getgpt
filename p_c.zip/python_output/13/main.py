# Given tuples
tuple1 = (13, 42, 53, 64, 75)
tuple2 = ('cat', 'dog', 'bat')

# 1. Accessing elements of a tuple
print("Accessing elements of tuple1:")
print("First element:", tuple1[0])  # Access by index
print("Last element:", tuple1[-1])  # Access by negative index

# 2. Slicing a tuple
print("\nSlicing tuple1:")
print("Elements from index 1 to 3:", tuple1[1:4])  # Slice from index 1 to 3

# 3. Concatenating two tuples
print("\nConcatenating tuple1 and tuple2:")
tuple3 = tuple1 + tuple2
print("Result of concatenation:", tuple3)

# 4. Repeating a tuple
print("\nRepeating tuple2 2 times:")
tuple4 = tuple2 * 2
print("Result of repetition:", tuple4)

# 5. Checking if an element exists in a tuple
print("\nChecking if 'dog' is in tuple2:")
print("'dog' in tuple2:", 'dog' in tuple2)  # Check if an element exists

# 6. Getting the length of a tuple
print("\nGetting the length of tuple1:")
print("Length of tuple1:", len(tuple1))  # Get the length of tuple

# 7. Counting occurrences of an element
print("\nCounting occurrences of 'cat' in tuple2:")
print("Count of 'cat' in tuple2:", tuple2.count('cat'))

# 8. Finding the index of an element
print("\nFinding the index of 'bat' in tuple2:")
print("Index of 'bat' in tuple2:", tuple2.index('bat'))

# 9. Iterating through a tuple
print("\nIterating through tuple1:")
for item in tuple1:
    print(item, end=" ")

# 10. Nested tuples
print("\n\nCreating and accessing nested tuple:")
nested_tuple = ((13, 42), (53, 64), (75,))
print("Second element of the first nested tuple:", nested_tuple[0][1])

# 11. Converting a tuple to a list
print("\nConverting tuple1 to a list:")
list_from_tuple = list(tuple1)
print("Converted list:", list_from_tuple)

# 12. Converting a list back to a tuple
print("\nConverting the list back to a tuple:")
tuple_from_list = tuple(list_from_tuple)
print("Converted tuple:", tuple_from_list)
