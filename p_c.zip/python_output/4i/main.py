lower=int(input("Enter lower range: "))
upper=int(input("Enter upper range: "))
print("The multiples of 3 but not divisible of 5 within given range are: ")
for i in range(lower,upper+1):
    if(i%3==0 and i%5!=0):
        print(i,'\t')
