def selection_sort(elements):
    """Sorts a list using the selection sort algorithm."""
    n = len(elements)
    for i in range(n):
        # Assume the minimum is the first element
        min_index = i
        # Iterate through the unsorted elements
        for j in range(i + 1, n):
            if elements[j] < elements[min_index]:
                min_index = j
        # Swap the found minimum element with the first element
        elements[i], elements[min_index] = elements[min_index], elements[i]

# Example usage
if __name__ == "__main__":
    # Ask the user for the number of elements
    try:
        num_elements = int(input("Enter the number of data to sort: "))
    except ValueError:
        print("Invalid input. Please enter a valid number.")
        exit()

    # Initialize the list to store numbers
    elements = []

    # Collect the numbers from the user
    for i in range(num_elements):
        while True:
            try:
                number = float(input("Enter the next data: "))  # Allow float input
                elements.append(number)
                break
            except ValueError:
                print("Invalid input. Please enter a valid number.")

    # Sort the elements using selection sort
    selection_sort(elements)

    # Display the sorted elements
    print("Sorted elements:", elements)
