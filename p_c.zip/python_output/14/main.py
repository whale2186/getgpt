# Creating a dictionary
my_dict = {
    'name': 'Alice',
    'age': 25,
    'city': 'New York',
    'hobbies': ['reading', 'traveling', 'music']
}

# 1. Accessing values using keys
print("Accessing values:")
print("Name:", my_dict['name'])
print("Age:", my_dict['age'])
print("City:", my_dict['city'])

# 2. Modifying values
print("\nModifying values:")
my_dict['age'] = 26  # Update age
print("Updated Age:", my_dict['age'])

# 3. Adding new key-value pairs
print("\nAdding new key-value pairs:")
my_dict['email'] = 'alice@example.com'
print("Updated Dictionary:", my_dict)

# 4. Deleting a key-value pair
print("\nDeleting a key-value pair:")
del my_dict['city']
print("Dictionary after deletion:", my_dict)

# 5. Checking if a key exists
print("\nChecking if a key exists:")
print("Is 'name' in the dictionary?", 'name' in my_dict)
print("Is 'city' in the dictionary?", 'city' in my_dict)

# 6. Getting all keys and values
print("\nGetting all keys and values:")
print("Keys:", my_dict.keys())
print("Values:", my_dict.values())

# 7. Iterating through a dictionary
print("\nIterating through the dictionary:")
for key, value in my_dict.items():
    print(f"{key}: {value}")

# 8. Copying a dictionary
print("\nCopying the dictionary:")
copied_dict = my_dict.copy()
print("Copied Dictionary:", copied_dict)

# 9. Clearing a dictionary
print("\nClearing the dictionary:")
my_dict.clear()
print("Dictionary after clearing:", my_dict)  # Should be empty

# 10. Creating a dictionary using dictionary comprehension
print("\nCreating a dictionary using dictionary comprehension:")
squares = {x: x**2 for x in range(1, 6)}  # Dictionary of squares from 1 to 5
print("Squares Dictionary:", squares)
