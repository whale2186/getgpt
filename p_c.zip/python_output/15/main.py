def copy_file_contents(source_file, destination_file):
    try:
        # Open the source file in read mode
        with open(source_file, 'r') as src:
            # Read the contents of the source file
            content = src.read()

            # Count the number of words in the content
            words = content.split()
            word_count = len(words)

        # Open the destination file in write mode
        with open(destination_file, 'w') as dest:
            # Write the contents to the destination file
            dest.write(content)

        # Return the word count
        return word_count

    except FileNotFoundError:
        print(f"Error: The file {source_file} was not found.")
        return 0
    except Exception as e:
        print(f"An error occurred: {e}")
        return 0

# Example usage:
source_file = 'source.txt'  # Replace with the source file name
destination_file = 'destination.txt'  # Replace with the destination file name

# Call the function and get the word count
word_count = copy_file_contents(source_file, destination_file)

# Display the result
if word_count > 0:
    print(f"Successfully copied {word_count} words from {source_file} to {destination_file}.")
